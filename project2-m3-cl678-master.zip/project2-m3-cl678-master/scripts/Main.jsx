import * as React from 'react';
import * as ReactDOM from 'react-dom';

import { Login } from './Login';

ReactDOM.render(<Login />, document.getElementById('content'));
